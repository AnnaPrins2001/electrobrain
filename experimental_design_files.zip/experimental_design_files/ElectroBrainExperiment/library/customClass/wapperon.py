##############################################################################
# CustomClass Rules                                                          #
# =================                                                          #
#                                                                            #
#1. All custom classes must inherit sreb.EBObject and the constructor        #
#   must call sreb.EBObject's constructor. If a class starts with _ then it  #
#   is considered internal and will not be treated as a custom class.        #
#                                                                            #
#2. The custom class will only use the default constructor.                  #  
#   ie. a constructor with no parameters.                                    #
#                                                                            #
#3. To add a property provide getter and have an attribute that does not     #
#   starts with an underscore(_) or an upper case letter, and have the       #
#   attribute of a know type. Known types are int,float,str,EBPoint,EBColor, #
#   tuple, and list.                                                         #
#   If an attribute's default value is of type tuple and only has two        #
#   items, the property will be treated as an EBPoint. Similarly, if an      #
#   attribute's default value is a tuple of 3 items the property will be     #
#   treated as an EBColor.  The input type of the setter and the output type #
#   of the getter is expected to be the same as the type of the attribute.   #
#                                                                            #
#4. If only getter is provided, the property will be a readonly property.    # 
#                                                                            #
#6. The custom class may be instanciated during development to obtain        # 
#   class info. Avoid such things as display mode change, remote connections # 
#   in the constructor.                                                      #
#                                                                            # 
#7. Any method in the custom class can be called using the Execute action    #
#   By default, the return type of the method is string unless a doc string  #
#   with the following constraint is available                               #
#	a. The doc string starts with "RETURN:" (case matters)               #
#       b. Following the text "RETURN:" provide a default value of the type  #
#          or the __repr__ value of the class. eg. str for string            #
#8. If a property's setter metthod has default values for it's parameters,   #
#    the property will not accept references or equation.                    #
##############################################################################


import sreb


import sreb
import telnetlib
import time
import numpy as np



verbose = False;
wait_time = 0.025; # probably not change this
# REAL_MEASUREMENT = True # change, depending whether it is a dummy or a real measurement 

# HOST = "http://100.1.1.10:5023"
# user = raw_input("Enter your remote account: ")
# password = getpass.getpass()
# STATE = 1;

# tn = telnetlib.Telnet("100.1.1.10", "5023", timeout=0.1)
# tn.read_until("login: ")
# tn.write(user + "\n")
# if password:
#     tn.read_until("Password: ")
#     tn.write(password + "\n")

def send_telnet_signal(message):
    # this is not the best way to use telnet
    # you should probably rather use something like read_until
    # and then search/look for the SCPI> prompt, which the agilent will return
    # ... for now, I will just use this (less optimal) way because - it works
    # one can send any message BTW, also messages to recalling a certain memory
    # state, or setting the dbm to some higher level.

    try:
        if verbose:
            print('sending: %s' % message)
            
        tn = telnetlib.Telnet("100.1.1.10", "5023", timeout=wait_time)
        tn.write(message)
        if verbose:
            print(tn.read_all())
        else:
            tn.read_all()
    except:
        pass
        

def make_power_list(onoff, isreal):
    if isreal:
        if onoff == 'ON':
            power_list = range(-136, 12, 5)
            power_list.append(12)
        if onoff == 'OFF':
            power_list = range(12, -136, -5)
            power_list.append(-136)


    if not isreal:
        if onoff == 'ON':
            power_list = [] 
            #range(-136, -125, 5)
            for i in range(6):
                power_list.extend([-125])
                power_list.extend([-120])
                power_list.extend([-115])
                power_list.extend([-110])
                # power_list.extend(range(-115, -137, -5))
                # power_list.extend([-125])
            power_list.extend([-120])
            power_list.extend([-136])
        elif onoff == 'OFF':
            power_list = [-136]
            power_list.extend([-130])
            power_list.extend([-125])

            for i in range(6):
                power_list.extend([-110])
                power_list.extend([-115])
                power_list.extend([-120])
                power_list.extend([-125])
                # power_list.extend(range(-115, -137, -5))
                # power_list = range(-125, -136, -5)
        power_list.append(-136)
    return power_list


def switch_it(onoff, isreal):

    power_list = make_power_list(onoff, isreal)
    
    if onoff == 'ON' or onoff == 'OFF' and not isreal:
        send_telnet_signal("power:state on\n")

    for power in power_list:
        send_telnet_signal("power:amplitude %s dbm\n" % str(power))

    
    if onoff == 'OFF' or onoff == 'ON' and not isreal:
        send_telnet_signal("power:state off\n")




class CustomClassTemplate(sreb.EBObject):
	def __init__(self):
		sreb.EBObject.__init__(self)

		self.property1 = 0;
		self.subject1 = '0';


	def setProperty1(self, c):
		self.property1 = c

	def getProperty1(self):
		return self.property1


	def setSubject1(self, c):
		self.subject1 = c

	def getSubject1(self):
		return self.setSubject1


	def checkSubjWapperOn(self):


		subj = self.subject1

		if isinstance(subj, str):
			this_subj = int(subj)
			print('Entered: %s' % subj)


		fname = 'C:/Randomization/Randomization.txt'
		m = np.loadtxt(fname, dtype=int)

		# we go through the matrix and check if sub is IT:

		if this_subj not in m[:,0]:
			print('%s was not in the Randomization Matrix!')
			# self.wapperon()
			raise Exception('Check Your Randomizations')
		else:
			print('found it!')


		for sub, first, second in m:
			if sub == this_subj:
				found_it = True
				if first == 1:
					isreal = True
					# print('switched on')
				if first == 0:
					isreal = False
					# print('switched on')

		if found_it:
			switch_it('ON', isreal) # we always switch it ON.




	def checkSubjWapperOFF(self):


		subj = self.subject1

		if isinstance(subj, str):
			this_subj = int(subj)
			print('Entered: %s' % subj)


		fname = 'C:/Randomization/Randomization.txt'
		m = np.loadtxt(fname, dtype=int)

		# we go through the matrix and check if sub is IT:

		if this_subj not in m[:,0]:
			print('%s was not in the Randomization Matrix!')
			# self.wapperon()
			raise Exception('Check Your Randomizations')
		else:
			print('found it!')


		for sub, first, second in m:
			if sub == this_subj:
				found_it = True
				if first == 1:
					isreal = True
					# print('switched on')
				if first == 0:
					isreal = False
					# print('switched on')

		if found_it:
			switch_it('OFF', isreal) # we always switch it ON.


			


	def wapperonoff(self):
		tn = telnetlib.Telnet("100.1.1.10", "5023", timeout=0.1)
		tn.write("OUTPUT:State ON\n")
		#with open("test.txt","w+") as f:
			#f.write("hallo")
		try:
			print(tn.read_all()) # must do this otherwise it won't do it
		except:
			pass
	
	def wapperon(self):

		print('hallo!')

		print(self)
	
		tn = telnetlib.Telnet("100.1.1.10", "5023", timeout=0.1)
		tn.write("OUTPUT:State ON\n")
		#with open("test.txt","w+") as f:
			#f.write("hallo")
		try:
			print(tn.read_all()) # must do this otherwise it won't do it
		except:
			pass

	def wapperoff(self):
		tn = telnetlib.Telnet("100.1.1.10", "5023", timeout=0.1)
		tn.write("OUTPUT:State OFF\n")
		#with open("test.txt","w+") as f:
			#f.write("hallo")
		try:
			print(tn.read_all()) # must do this otherwise it won't do it
		except:
			pass
			
			
		


			
	
