# -*- coding: UTF-8 -*-
##############################################################################
# CustomClass Rules                                                          #
# =================                                                          #
#                                                                            #
#1. All custom classes must inherit sreb.EBObject and the constructor        #
#   must call sreb.EBObject's constructor. If a class starts with _ then it  #
#   is considered internal and will not be treated as a custom class.        #
#                                                                            #
#2. The custom class will only use the default constructor.                  #  
#   ie. a constructor with no parameters.                                    #
#                                                                            #
#3. To add a property provide getter and have an attribute that does not     #
#   starts with an underscore(_) or an upper case letter, and have the       #
#   attribute of a know type. Known types are int,float,str,EBPoint,EBColor, #
#   tuple, and list.                                                         #
#   If an attribute's default value is of type tuple and only has two        #
#   items, the property will be treated as an EBPoint. Similarly, if an      #
#   attribute's default value is a tuple of 3 items the property will be     #
#   treated as an EBColor.  The input type of the setter and the output type #
#   of the getter is expected to be the same as the type of the attribute.   #
#                                                                            #
#4. If only getter is provided, the property will be a readonly property.    # 
#                                                                            #
#6. The custom class may be instanciated during development to obtain        # 
#   class info. Avoid such things as display mode change, remote connections # 
#   in the constructor.                                                      #
#                                                                            # 
#7. Any method in the custom class can be called using the Execute action    #
#   By default, the return type of the method is string unless a doc string  #
#   with the following constraint is available                               #
#	a. The doc string starts with "RETURN:" (case matters)               #
#       b. Following the text "RETURN:" provide a default value of the type  #
#          or the __repr__ value of the class. eg. str for string            #
#8. If a property's setter metthod has default values for it's parameters,   #
#    the property will not accept references or equation.                    #
##############################################################################


import sreb




class CustomClassTemplate(sreb.EBObject):
	def __init__(self):
		sreb.EBObject.__init__(self)
		self.property1=1       #property of Integer type. This is also a read,write property. see the getter and setter
		self.property2=(1,2)   #read only point property. Note the setter missing for this property.
		self.property3=(1,2,3) #read only color property. Note the setter missing for this property.
		self.property4=1.0     #read and write property of double type, also will not accept references or equation.
		self.property5=sreb.EBPoint(100,200) #read, write point property. Note this property is similar to proprty2 except the writeableness.
		self.property6=sreb.EBColor(200,100,100) #read, write color property. Note this property is similar to proprty3 except the writeableness.
		self.property7=[1,'abc',self.property6] #read,write eblist property.
		self.property8='hello'  #read,write string property.
		self._myInternalAttribute="My Internal Attribute" #string property, however this is hidden from the interface.
		
	#
	#Property: property1
	#A read and write integer type property
	def setProperty1(self,c):
		self.property1=c
	
	def getProperty1(self):
		return self.property1
	
	#
	#Property: property2
	#A read only property.  The type will be treated as a point(EBPoint)
	def getProperty2(self):
		return self.property2
	
	def getProperty3(self):
		return self.property3
		
	#
	#Callable method using Execute action. 
	#Note the default arguments and the doc string to let eb know what is the expected return type.
	def myMethod(self,param1,param2=[100,1,1,1], param3=(100,100,50), param4=(50,75),param5="hi"):
		"""RETURN:[1000,2000,3000]""" #The first line of the doc of method is used to get the return type of the method.
		return [1000,2000,3000]
	
	
	#internal method
	def _myInternalMethod(self):
		pass
		
	#
	#Property: property4
	#A read and write float type property
	def setProperty4(self,c=5.7):
		self.property4=c
	
	def getProperty4(self):
		return self.property4
	
	#
	#Property: property5
	#A read and write EBPoint type property
	def setProperty5(self,c):
		self.property5=c
	
	def getProperty5(self):
		return self.property5
		
	#
	#Property: property6
	#A read and write EBColor type property
	def setProperty6(self,c):
		self.property6=c
	
	def getProperty6(self):
		return self.property6
		
	#
	#Property: property7
	#A read and write list type property
	def setProperty7(self,c):
		self.property7=c
	
	def getProperty7(self):
		return self.property7
		
	#
	#Property: property8
	#A read and write string type property
	def setProperty8(self,c):
		self.property8=c
	
	def getProperty8(self):
		return self.property8
