##############################################################################
# CustomClass Rules                                                          #
# =================                                                          #
#                                                                            #
#1. All custom classes must inherit sreb.EBObject and the constructor        #
#   must call sreb.EBObject's constructor. If a class starts with _ then it  #
#   is considered internal and will not be treated as a custom class.        #
#                                                                            #
#2. The custom class will only use the default constructor.                  #  
#   ie. a constructor with no parameters.                                    #
#                                                                            #
#3. To add a property provide getter and have an attribute that does not     #
#   starts with an underscore(_) or an upper case letter, and have the       #
#   attribute of a know type. Known types are int,float,str,EBPoint,EBColor, #
#   tuple, and list.                                                         #
#   If an attribute's default value is of type tuple and only has two        #
#   items, the property will be treated as an EBPoint. Similarly, if an      #
#   attribute's default value is a tuple of 3 items the property will be     #
#   treated as an EBColor.  The input type of the setter and the output type #
#   of the getter is expected to be the same as the type of the attribute.   #
#                                                                            #
#4. If only getter is provided, the property will be a readonly property.    # 
#                                                                            #
#6. The custom class may be instanciated during development to obtain        # 
#   class info. Avoid such things as display mode change, remote connections # 
#   in the constructor.                                                      #
#                                                                            # 
#7. Any method in the custom class can be called using the Execute action    #
#   By default, the return type of the method is string unless a doc string  #
#   with the following constraint is available                               #
#	a. The doc string starts with "RETURN:" (case matters)               #
#       b. Following the text "RETURN:" provide a default value of the type  #
#          or the __repr__ value of the class. eg. str for string            #
#8. If a property's setter metthod has default values for it's parameters,   #
#    the property will not accept references or equation.                    #
##############################################################################


import sreb


import sreb
import telnetlib
import time
import numpy as np

class CustomClassTemplate(sreb.EBObject):
	def __init__(self):
		sreb.EBObject.__init__(self)

		self.property1 = 0;
		self.subject1 = '0';


	def setProperty1(self, c):
		self.property1 = c

	def getProperty1(self):
		return self.property1


	def setSubject1(self, c):
		self.subject1 = c

	def getSubject1(self):
		return self.setSubject1


	def checkSubjWapperOn(self):


		subj = self.subject1

		if isinstance(subj, str):
			this_subj = int(subj)
			print('Entered: %s' % subj)


		fname = 'C:/Randomization/Randomization.txt'
		m = np.loadtxt(fname, dtype=int)

		# we go through the matrix and check if sub is IT:

		if this_subj not in m[:,0]:
			print('%s was not in the Randomization Matrix!')
			# self.wapperon()
			raise Exception('Check Your Randomizations')
		else:
			print('found it!')


		for sub, first, second in m:
			if sub == this_subj:
				found_it = True
				if second == 1:
					self.wapperon()
					# print('switched on')
				if second == 0:
					self.wapperoff()
					# print('switched on')
		
			
			


	def wapperonoff(self):
		tn = telnetlib.Telnet("100.1.1.10", "5023", timeout=0.1)
		tn.write("OUTPUT:State ON\n")
		#with open("test.txt","w+") as f:
			#f.write("hallo")
		try:
			print(tn.read_all()) # must do this otherwise it won't do it
		except:
			pass
	
	def wapperon(self):

		print('hallo!')

		print(self)
	
		tn = telnetlib.Telnet("100.1.1.10", "5023", timeout=0.1)
		tn.write("OUTPUT:State ON\n")
		#with open("test.txt","w+") as f:
			#f.write("hallo")
		try:
			print(tn.read_all()) # must do this otherwise it won't do it
		except:
			pass

	def wapperoff(self):
		tn = telnetlib.Telnet("100.1.1.10", "5023", timeout=0.1)
		tn.write("OUTPUT:State OFF\n")
		#with open("test.txt","w+") as f:
			#f.write("hallo")
		try:
			print(tn.read_all()) # must do this otherwise it won't do it
		except:
			pass
			
			
		


			
	
